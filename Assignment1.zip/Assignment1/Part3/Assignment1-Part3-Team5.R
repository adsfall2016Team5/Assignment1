library(rvest)

#XML package helps to read and parse XML data coming from webpage
library(XML)

#Extract Line Items of 2012 
LI2012 <- data.frame(read.csv("2012LI.csv", header = TRUE))
LI2012$DT <- as.Date(LI2012$DT,"%Y%m%d")
LI2012 <- LI2012[-1,]
rownames(LI2012) <- NULL
head(LI2012)

#Extract Line Items of 2012 
LI2013 <- data.frame(read.csv("2013LI.csv", header = TRUE))
LI2013$DT <- as.Date(LI2013$DT,"%Y%m%d")
LI2013 <- x2[-1,]
rownames(LI2013) <- NULL
head(LI2013)

#Extract Line Items of 2012 
LI2014 <- data.frame(read.csv("2014LI.csv", header = TRUE))
LI2014$DT <- as.Date(LI2014$DT,"%Y%m%d")
LI2014 <- LI2014[-1,]
rownames(LI2014) <- NULL
head(LI2014)

#Combine data from all 3 years Line Items
AllyearsLI <- rbind(LI2012,LI2013,LI2014)
head(AllyearsLI)

finaldata <- data.frame(AllyearsLI)
#Replace All Nulls with '0'
finaldata[,] <- as.character.default(gsub("<NULL>", 0, as.matrix(finaldata[,])))

final <- as.data.frame(finaldata)
#final[is.na(final)] <- 0
head(final)
final$DT <- as.Date(final$DT,"%Y%m%d")

write.csv(final, file = "AllYearsLI.csv")
