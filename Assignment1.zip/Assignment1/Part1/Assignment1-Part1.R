#RSelenium package helps to communicate with a selenium RemoteWebDriver Server. So that you can use this server to launch web page and navigate through url
install.packages("RSelenium")
library(RSelenium)

checkForServer()

#Start Selenium Server
startServer()

Sys.sleep(5)

#Connecting to selenium RemoteWebDriver Server
remDrv <- remoteDriver(remoteServerAddr = "localhost", port = 4444, browserName = "firefox")

#open the connection with firefox
remDrv$open()

#Navigate through URL you want
remDrv$navigate("https://www.ffiec.gov/nicpubweb/nicweb/HCSGreaterThan10B.aspx")

#Fetch List of Quarter from dropdown
iframe <- remDrv$findElement(using='id', value="DateDropDown")


#XML package helps to read and parse XML data coming from webpage
library(XML)
webpage <- readLines("https://www.ffiec.gov/nicpubweb/nicweb/HCSGreaterThan10B.aspx")
htmlpage <- htmlParse(webpage, asText = TRUE)
htmlpage

#xpathSapply helps you to identify html nodes using some criteria and iterates that function over webpage
#Here it extracts the list of quarter from dropdown
timeframe <- xpathSApply(htmlpage, "//option", function(u) xmlAttrs(u)["value"])
as.numeric(timeframe)


for(i in timeframe){
        
        #Finds element based on your criteria
        option <- remDrv$findElement(using = 'xpath', paste('//*/option[@value=',i,"]"))
        option$clickElement()
        
        
        #gets entire page source of that specific webpage
        doc <- htmlParse(remDrv$getPageSource()[[1]])
        
        
        Sys.sleep(2)
        tables <- getNodeSet(doc, "//table")
        Sys.sleep(2)
        
        #Reades entire table in data frame format,including header
        
        tablecontents <- readHTMLTable(tables[[3]],
                            header = TRUE,
                            as.data.frame = TRUE,
                            colClasses = c("numeric","character","character",
                                           "character"),
                            trim = TRUE, stringsAsFactors = FALSE
        )
        
        #Writes contents of that table of the specific quarter into csv file
        write.csv(tablecontents, file = paste("quarter-",i,'.csv'))
}


# Stacking

StackedCSV = NULL

for (i in timeframe){
        Quarterdata <- data.frame(read.csv(paste("quarter-",i,".csv"), header = TRUE))
        x<-replicate(nrow( Quarterdata),i)
        Quarterdata$quarter <- as.Date(x,"%Y%m%d")
        colnames( Quarterdata) <- c('SNo', 'Rank','Company', 'Location', 'Assets', 'Quarter')
        StackedCSV <- rbind(StackedCSV, Quarterdata)
}



#splitting company ID and Location
install.packages('reshape2')
library(reshape2)

#Splitting Location into City and state , Company into Institution Name and RSSDId
NewStackedCSV <- with(StackedCSV, cbind(SNo,Rank, colsplit(StackedCSV$Company, pattern = "\\(", names = c('Institution Name', 'RSSDId')),colsplit(StackedCSV$Location, pattern = "\\,", names = c('City', 'State')), Assets, Quarter))

finalStackedCSV <- as.data.frame(sapply(NewStackedCSV,gsub,pattern=")",replacement=""))



#writing as a stacked CSV 
write.csv(finalStackedCSV, file = "AllQuarters-1.csv")

#Unstacking
getwd()
setwd("/Users/jayeshsamyani/Desktop/ADS-Assignment1/Part1/")
UnStackedCSV = NULL
Final=NULL
for (i in timeframe){
        unstackeddata <- data.frame(read.csv("quarter- 20160630 .csv"), header = TRUE)
        unstackeddata1 <- data.frame(read.csv("quarter- 20160331 .csv"), header = TRUE)
        x<-replicate(nrow(unstackeddata),i)
        colnames( unstackeddata) <- c('SNo', 'Rank','Company', 'Location', 'Assets', 'Quarter')
        unstackeddata$quarter <- as.Date(x,"%Y%m%d")
        
        y<-replicate(nrow(unstackeddata1),i)
        colnames( unstackeddata1) <- c('SNo', 'Rank','Company', 'Location', 'Assets', 'Quarter')
        unstackeddata1$quarter <- as.Date(y,"%Y%m%d")
}
        NewUnStackedCSV <- with(unstackeddata, cbind(SNo,Rank, colsplit(unstackeddata$Company, pattern = "\\(", names = c('Institution Name', 'RSSDId')),colsplit(unstackeddata$Location, pattern = "\\,", names = c('City', 'State')), Assets, Quarter))
        
        NewUnStackedCSV1 <- with(unstackeddata1, cbind(SNo,Rank, colsplit(unstackeddata1$Company, pattern = "\\(", names = c('Institution Name', 'RSSDId')),colsplit(unstackeddata1$Location, pattern = "\\,", names = c('City', 'State')), Assets, Quarter))
        
        
        
       Final<- merge(NewUnStackedCSV,NewUnStackedCSV1,by=3,all.x = TRUE,all.y = TRUE)
        






