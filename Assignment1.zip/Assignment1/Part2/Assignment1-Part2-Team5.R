#Tabula is a Java library designed to computationally extract tables from PDF documents.
#tabulizer is a package helps you extract pdf's into tables.
library("tabulizer")
library("rjava")
#Stringr package is used for manipulating string, used for cleaning data and bringing data in correct format
library("stringr")
setwd("/Users/jayeshsamyani/Desktop/ADS-Assignment1/Part2/AllCsv's")
getwd()

#filename <- "PeerGroup_1_December2015.pdf"
filename <- k
Quarter <- "Q3"
Year <- "2010"
filepath <-system.file("examples", " PeerGroup_1_Dec2009.pdf", package="tabulizer")
#extract tables() of tabulizer helps to extract pdf contents into tabuler format
#Divide PDF into 2 parts subset 1(1-13) and subset 2(14-26),  as rows for both subsets are same, so combine columns of 2nd subset with rows of 1st subset
subset1 <- extract_tables(filepath,guess=TRUE,method = "data.frame",pages = c(1:13))
subset2 <- extract_tables(filepath,guess=FALSE,method = "data.frame",pages = c(14:26))

dfresult <- NULL

headerdf2_2<-c("X", "RATIO","5%10%","25%","50%","75%","90%","95%","Count")
headerdf2_1<-c("X", "RATIO5%","10%","25%","50%","75%","90%","95%","Count")
headerdf2_3<-c("X", "RATIO5%10%","25%","50%","75%","90%","95%","Count")
headerdf2<-c("X", "RATIO","5%","10%","25%","50%","75%","90%","95%","Count")
headeredf1 <- c("X")



i<-1

while(i<14)
{     
        print(i)
        #replace empty spaces in 2nd subset with NA's(which were introduced due to spaces)
        df2 <-as.data.frame(apply(subset2[[i]], 2, function(x) gsub("^$|^ $", NA, x)))
        
        #Remove all rows which have NA's(which were introduced due to spaces) from subset 2 
        row.has.na <-(apply(df2, 1, function(x){all(is.na(x))}))
        sum(row.has.na)
        df2 <-as.data.frame(df2[!row.has.na,])
        
        #Removing unwanted data from subset 2
        if(i==1)
        {
                df2 <- df2[-c(1:3),]
        }
        else{
                df2 <- df2[-c(1:2),]
            }
        
        #Remove rows which have "-----" in 2nd subset (Not Needed)
        del<-which(apply(df2, 1, function(x) any(grepl("\\--", x))))
        if(length(del)>0)
                df2<-df2[-(del),]
        
        #Taking 1st Row and making it as header and then removing 1st row.
        names(df2)=unlist(df2[c(1),])
        df2 <- as.data.frame(df2[-1,])
        
        #Remove all columns which have NA's for 2nd subset
        col.has.na <-(apply(df2, 2, function(x){all(is.na(x))}))
        sum(col.has.na)
        df2 <-as.data.frame(df2[,!col.has.na])
     
        #replace empty spaces in 1st subset with NA's(which were introduced due to space)
        df1 <-as.data.frame(apply(subset1[[i]], 2, function(x) gsub("^$|^ $", NA, x)))
    
        #Remove rows which have "-----" in 1st subset (Not Needed)
        del<-which(apply(df1, 1, function(x) any(grepl("\\--", x))))
        if(length(del)>0)
                df1<-df1[-(del),]
        
        #Remove all rows which have NA's(which were introduced due to space) for 1st subset
        row.has.na <-(apply(df1, 1, function(x){all(is.na(x))}))
        sum(row.has.na)
        df1 <-as.data.frame(df1[!row.has.na,])
        
        
        colnames(df1)[1] <- "X"

        # Adding delimiter between columns which are merged in data frame, so that you can separate columns using it 
        df2 <-as.data.frame(apply(df2, 2, function(x) gsub("(-?[0-9 ]*.[0-9]{2})(-?[0-9])", "\\1,\\2",  x)))
        
         dftemp <- df2[,2]
    
      #   ddww <- as.character(dftemp)
      #   na.omit("ddww")
         
         #counting number of delimiters in 1 column so that we can split columns accordingly
         counter <- str_count(dftemp[11],",")
         
         #Split coulmns based on limiter to number of columns based on counter 
        final <-as.data.frame(str_split_fixed(dftemp,",",counter+1))
        
        #Drop the merged column
        df2<- df2[,-2]
        
        #Append the new splitted columns into original data frame at its original place
       df2 <-  as.data.frame(append(df2,final,after = 1))
       
       #Give Header to subset 2, so that we can  rbind (same number of columns and same names for all columns)
       names(df2)<-headerdf2
       
       print(nrow(df1))
       print(nrow(df2))
       
       #Combine all columns to rows which are same from both subsets 
       if(nrow(df1)==nrow(df2))
                 df <-(cbind(as.data.frame(df1),as.data.frame(df2)))
        
    
     #  Combine all rows of pdf into 1 data frame
       dfresult <- rbind(dfresult,df)
       i <- i+1
       
}

write.csv(dfresult, file = paste("Peer1","_",Year,"_",Quarter,'.csv'))



