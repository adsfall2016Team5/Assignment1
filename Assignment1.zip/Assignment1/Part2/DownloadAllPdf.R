library(rvest)
library(RCurl)
require(RSelenium)
checkForServer()
startServer()
Sys.sleep(5)
remDr <- remoteDriver(remoteServerAddr = "localhost", port = 4444, browserName = "firefox")
remDr$open()
url<- "https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/BHCPR_Peer.htm"
remDr$navigate(url)
i=1
j=2
while(i<14)
{
        j=2
        print(i)
        while(j<=5)
        {
                print(j)
                tryCatch(
                        {
                                a<- remDr$findElement(using = 'xpath',paste("/html/body/div[2]/table[",i,"]/tbody/tr[2]/td[",j,"]/a"))
                                link<-as.character(a$getElementAttribute("href"))
                                if(!link=='')
                                {
                                        print(link)
                                        filename<-basename(link)
                                        download.file(link,destfile=paste("/Library/Frameworks/R.framework/Versions/3.3/Resources/library/tabulizer/examples/",filename),method="libcurl",mode="wb")
                                        Sys.sleep(2)
                                        
                                       
                                }
                        },
                        error=function(cond) {
                                message(paste("URL does not seem to exist:", url))
                                message("Here's the original error message:")
                                message(cond)
                                # Choose a return value in case of error
                                
                        },
                        finally = {
                                j=j+1
                        }
                )
        }
        i=i+1
}


listofpdf <- list.files(path="/Library/Frameworks/R.framework/Versions/3.3/Resources/library/tabulizer/examples/",pattern="\\.pdf$")
