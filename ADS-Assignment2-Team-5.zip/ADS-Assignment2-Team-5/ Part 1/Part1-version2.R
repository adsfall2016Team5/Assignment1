
install.packages("weatherData")
library(weatherData)

install.packages("devtools")
library("devtools")
install_github("Ram-N/weatherData")

install.packages("lubridate")
library(lubridate)

install.packages("chron")
library(chron)

install.packages("zoo")
library(zoo)


d3<- getWeatherForDate("KBOS", start_date="2014-01-01",
                       end_date = "2014-12-31",
                       opt_detailed = TRUE,opt_custom_columns = T,
                       custom_columns=c(2,3,4,5,6,7,8,12,13))

getwd()
 setwd("/Users/jayeshsamyani/Desktop/ADS/Assignment 2(1)")

data1 <- read.csv("rawData1.csv",header = TRUE)

data2 <- read.csv("rawData2.csv",header = TRUE)

Combineddata <- rbind(data1,data2)
y<- 1
Account <- NULL
Datecol <- NULL


while(y<nrow(Combineddata))
{
        Account<-rbind(Account,data.frame(x=Combineddata[y,1]))  
        
      
        
        Datecol <- rbind(Datecol,as.data.frame(x=Combineddata[y,2]))  
        
        y <- y+7
}


# Datecol[1,1]

data <- NULL
data <- rbind(data,Account)
ii <- 1
while(ii<24)
{
      
        data <- rbind(data,Account)
        # datecol1 <- rbind()
        ii <- ii+1;
}
# data$Date <- Datecol


kwhdata <- NULL
kwhdata2 <- NULL
result <- NULL
o <- 0
j <- 5
while(o<24) # following loop is used to bind 24hrs data of 1 day
{

tempj <- j+12  #tempj -following while loop is used to add 5 min interval for 1 hr
while(j<tempj) {
        kwhdata1 <- NULL
        i <- 1
        
        k <- 2#power factor
        l <- 3#KVAR
 
        
        while(i<nrow(Combineddata))
        {
                x <- 0
                y <- 0
                z <- 0
               # Combineddata[5,5]
                x <- x+Combineddata[i,j]
                x <- x+Combineddata[i+3,j]
                x <- x+Combineddata[i+5,j]
                
                y <- y+(Combineddata[k,j]*Combineddata[l,j])
                y <- y+(Combineddata[k,j]*Combineddata[l+2,j])
                y <- y+(Combineddata[k,j]*Combineddata[l+4,j])
                
                # Combineddata[1,17]
                z <- z+(x+y)
                if(j==5)
                {
                        kwhdata<-rbind(kwhdata,as.data.frame(x=z)) #KWHdata contains 5 min data for all 365 days
                } else
                {
                      
                        kwhdata1<-rbind(kwhdata1,as.data.frame(x=z))
                }
                        i <- i+7
                        l <- l+7
                        k <- k+7
        }
        if(!(j==5))
        {
             
               kwhdata<-cbind(kwhdata,data.frame(x=kwhdata1))  #KWHdata1 appends the data for 10th min ,15th min for all 365
                  
        }
      
        j <- j+1
}


o <- o+1

}



kwhdata
d <- 0
kwhdata2 <- Account

while(d<ncol(kwhdata))
{
        result <- 0
        f <- 1+d
        tempf=f+12
        while(f < tempf)
        {
                result <- result+kwhdata[,f]
                f <- f+1
        }
        kwhdata2<-cbind(kwhdata2,data.frame(x=result))
        d <- d+12
}



counterrow <- 1

kWh <- NULL
while(counterrow<=nrow(kwhdata2))
{
        countercol <- 2
while(countercol<=ncol(kwhdata2))
{

        kWh <- rbind(kWh,as.data.frame(kwhdata2[counterrow,countercol]))
        countercol <- countercol+1
}
        counterrow <- counterrow+1
}

finalKWH <- unlist(kWh)
class(finalKWH)

data$kWh <- finalKWH


#_____________________________ Date and other wheather variables except KWH and Account____________________# 

tempdate <- Combineddata[,2]
tempdate1 <-as.Date(tempdate,"%m/%d/%Y")
tempdate1


# fetching details from date column
datemonth <- format(tempdate1,"%m")
dateyear <- format(tempdate1,"%Y")
dateday <- format(tempdate1,"%d")

# install.packages("lubridate")
# library(lubridate)

dayofweek <- weekdays(tempdate1)
dayofweek <- wday(tempdate1)
dayofweek <- dayofweek-1
#dayofweek1 <- as.data.frame(dayofweek)
# install.packages("chron")
# library(chron)

ifweekend <- as.data.frame(is.weekend(tempdate1))

ifweekend <- as.vector(!ifweekend)
ifweekend <- as.data.frame(ifweekend)

for(i in nrow(ifweekend))
{
if(ifweekend[i,1]==FALSE)
{
       
        ifweekend[i,1] <- 1
}else{
       
        ifweekend[i,1] <- 0
        }
}

datedata <- data.frame("Date"=tempdate1,"Month"=datemonth,"Day"=dateday,"Year"=dateyear,"Day of Week"=dayofweek,"Weekday"=ifweekend)
nrow(datedata)


Datecol <- NULL
y <- 1
while(y<nrow(datedata))
{
        Account<-rbind(Account,data.frame(x=Combineddata[y,1]))  
        
        # tempdate <- Combineddata[y,2]
        # tempdate1 <-as.Date(tempdate,"%m/%d/%Y")
        
        Datecol <- rbind(Datecol,as.data.frame(x=datedata[y,]))  
        
        y <- y+7
}

Datecol1 <- NULL
Datecol$index = 1:nrow(Datecol)
Datecol1 = rbind(Datecol,Datecol)


Datecol1 = rbind(Datecol1,Datecol)




Datecol1 = rbind(Datecol1,Datecol1)
Datecol1 = rbind(Datecol1,Datecol1)
Datecol1 = rbind(Datecol1,Datecol1)


Datecol1 = Datecol1[order(Datecol1$index),][,-ncol(Datecol1)]



dates <- format(as.POSIXct(strptime(d3$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%m/%d/%Y")
hours <- format(as.POSIXct(strptime(d3$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%H")
d3$Date <- dates


d3$Date<- as.Date(d3$Date,format = "%m/%d/%Y")
d3$Hour <- as.numeric(hours)

# nrow(d3)
# colnames(d3)
# str(d3)

d3$Humidity <- as.numeric(d3$Humidity) #NAs introduced
d3$Wind_SpeedMPH <- as.numeric(d3$Wind_SpeedMPH) #NAs introduced


# install.packages("zoo")
# library(zoo)

# replace all NAs with the previous value
na.locf(d3$Humidity)
na.locf(d3$Wind_SpeedMPH)

i <- 1
# library(dplyr)
install.packages("dplyr")
 library(dplyr)
# 
#  
# d3new <- d3
# 
# d3 <- d3[,-1]

d3 = d3 %>% group_by(Date,Hour) %>% summarize(TemperatureF=mean(TemperatureF),
                                                    Dew_PointF=mean(Dew_PointF),
                                                    Humidity=mean(Humidity),
                                                    Sea_Level_PressureIn = mean(Sea_Level_PressureIn),
                                                    VisibilityMPH = mean(VisibilityMPH),
                                                    Wind_SpeedMPH = mean(Wind_SpeedMPH),
                                                    WindDirDegrees = mean(WindDirDegrees),
                                                    Conditions = max(Conditions),
                                                    Wind_Direction = max(Wind_Direction))
View(d3)
# d3$TemperatureF <- d3 %>% group_by(Date,Hour) %>% summarize(m=mean(TemperatureF))
# class(d3$TemperatureF)
# head(d3)
# unlist(d3$TemperatureF)
# while(i <= nrow(d3))
# {
#         if(identical(d3$Date[i],d3$Date[i+1]))
#         {
#                 if(identical(d3$Hour[i],d3$Hour[i+1]))
#                 {
#                         a <- c(d3$TemperatureF[i],d3$TemperatureF[i+1])
#                         b <- c(d3$Dew_PointF[i],d3$Dew_PointF[i+1])
#                         c <- c(d3$Humidity[i],d3$Humidity[i+1])
#                         d <- c(d3$Sea_Level_PressureIn[i],d3$Sea_Level_PressureIn[i+1])
#                         e <- c(d3$VisibilityMPH[i],d3$VisibilityMPH[i+1])
#                         f <- c(d3$Wind_SpeedMPH[i],d3$Wind_SpeedMPH[i+1])
#                         g <- c(d3$WindDirDegrees[i],d3$WindDirDegrees[i+1])
#                         
#                         d3$TemperatureF[i] <- mean(a)
#                         d3$Dew_PointF[i] <- mean(b)
#                         d3$Humidity[i] <- mean(c)
#                         d3$Sea_Level_PressureIn[i] <- mean(d)
#                         d3$VisibilityMPH[i] <- mean(e)
#                         d3$Wind_SpeedMPH[i] <- mean(f)
#                         d3$WindDirDegrees[i] <- mean(g)
#                         
#                         
#                         d3 <- d3[-(i+1),]
#                         rownames(d3) <- 1:nrow(d3)
#                 }else
#                 {
#                         
#                         i <- i+1
#                         
#                 }
#         }else
#         {
#                 i <- i+1
#         }
# }

# 
# d3 = d3 %>% group_by(Date,Hour) %>% summarize(TemperatureF=mean(TemperatureF),
#                                                                           Dew_PointF=mean(Dew_PointF),
#                                                                           Humidity=mean(Humidity),
#                                                                           Sea_Level_PressureIn = mean(Sea_Level_PressureIn),
#                                                                           VisibilityMPH = mean(VisibilityMPH),
#                                                                           Wind_SpeedMPH = mean(Wind_SpeedMPH),
#                                                                           WindDirDegrees = mean(WindDirDegrees),
#                                                                           Conditions = max(Conditions),
#                                                                           Wind_Direction = max(Wind_Direction),
#                                                                           Month= max(Month),Day=max(Day),Year=max(Year),
#                                                                           Day_of_Week=max(Day_of_Week),Weekday=max(Weekday),
#                                                                           peakhour=max(peakhour))

peakhour <- data.frame(c(1:8760))
Hour <-as.data.frame(Datecol1$Hour)
i <- 1

while(i<=nrow(Hour))
{

        if(Hour[i,1] >= 7 && Hour[i,1] < 19)
        {

             peakhour[i,1] <- 1
        }else if(Hour[i,1] >= 19 || Hour[i,1]<7)
        {

                peakhour[i,1] <- 0
        }
        i<-i+1
}

peakhour <- unlist(peakhour)
class(peakhour)
Datecol1$Peakhour <- as.numeric(peakhour)

####################################### end of weather data section
#Datecol1$id<-c(1:nrow(Datecol1))

Datecol1$Hour<-c(rep(0:23,times=365))
df3 <- NULL
df3<-merge(Datecol1,d3,by=c("Date","Hour"),all.x = TRUE)





temp <- cbind(data,df3)

# temp <- temp[,-11]
temp <- temp[c(1,3,2,5,6,7,4,8,9,10,11,12,13,14,15,16,17,18,19)]
colnames(temp) <-c("Account","Date","kWh","month","day","year","hour","Day of Week","Weekday","Peakhour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WinddirDegrees") 
finaldata <- as.data.frame(temp)
#finaldata <- finaldata[,-20]
write.csv(finaldata, file = "SampleFormat.csv")
str(finaldata)
getwd()











# Combining weather variables with Account and KWH

# install.packages("lubridate")
# library(lubridate)
# 
# install.packages("chron")
# library(chron)
# 
# tempdate <- Combineddata[,2]
# tempdate1 <-as.Date(tempdate,"%m/%d/%Y")
# tempdate1
# 
# 
# # fetching details from date column
# datemonth <- format(tempdate1,"%m")
# dateyear <- format(tempdate1,"%Y")
# dateday <- format(tempdate1,"%d")
# 
# 
# 
# dayofweek <- weekdays(tempdate1)
# dayofweek <- wday(tempdate1)
# 
# # install.packages("weatherData")
# # library(weatherData)
# 
# ifweekend <- as.data.frame(is.weekend(tempdate1))
# 
# for(i in nrow(ifweekend))
# {
# if(ifweekend[i,1]=="TRUE")
# {
#        ifweekend[i,1] <- "1"
# }else
#         ifweekend[i,1] <- "0"
# }
# datedata <- data.frame("Date"=tempdate1,"Month"=datemonth,"Day"=dateday,"Year"=dateyear,"Day of Week"=dayofweek,"Weekday"=ifweekend)
# 
# 
# 
# # d3<- getWeatherForDate("KBOS", start_date="2014-01-01",
# #                        end_date = "2014-01-01",
# #                        opt_detailed = TRUE,opt_custom_columns = T,
# #                        custom_columns=c(2,3,4,5,6,7,8,12,13))
# 
# 
# d3$Time <- format(d3$Time,"%H")
# d3$Time <- as.numeric(d3$Time)
# colnames(d3)[1] <- "Hour"
# 
# peakhour <- 0
# 
# 
# d3$Peakhour <- peakhour
# 
# 
# finaldata <- cbind(datedata,d3)
# 
# 
# finaldata <- finaldata[,c("Date","Month","Day","Year","Hour","Day.of.Week","Weekday","Peakhour",
#                           "TemperatureF","Dew_PointF","Humidity","Sea_Level_PressureIn",
#                           "VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WindDirDegrees")]
# 
# i <- 1
# while(i<=24)
# {
#         
#         if(finaldata[i,5] >= 7 && finaldata[i,5] < 19)
#         {
#                
#                 finaldata[i,8] <- 1
#         }else if(finaldata[i,5] >= 19 )
#         {
#                 
#                 finaldata[i,8] <- 0
#         }
#         i<-i+1
# }  
# finaldata