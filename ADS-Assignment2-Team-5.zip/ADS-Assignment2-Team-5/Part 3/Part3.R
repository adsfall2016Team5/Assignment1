forecastData <- read.csv("forecastData.csv",stringsAsFactors = FALSE)

class(forecastData$Time)

forecastData$Time <- as.POSIXct(forecastData$Time)

dates <- format(as.POSIXct(strptime(forecastData$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%m/%d/%Y")
hours <- format(as.POSIXct(strptime(forecastData$Time,"%Y-%m-%d %H:%M:%S",tz="")) ,format = "%H")
forecastData$Date <- dates
forecastData$Date<- as.Date(forecastData$Date,format = "%m/%d/%Y")
forecastData$Hour <- as.numeric(hours)


datemonth <- format(forecastData$Date,"%m")
dateyear <- format(forecastData$Date,"%Y")
dateday <- format(forecastData$Date,"%d")

forecastData$Day <- dateday
forecastData$Year <- dateyear
forecastData$Month <- datemonth

library(lubridate)
dayofweek <- weekdays(forecastData$Date)
dayofweek <- wday(forecastData$Date)
dayofweek <- dayofweek-1
forecastData$Day_of_Week <- dayofweek
ifweekend <- as.data.frame(is.weekend(forecastData$Date))

ifweekend <- as.vector(!ifweekend)
ifweekend <- as.data.frame(ifweekend)

for(i in nrow(ifweekend))
{
        if(ifweekend[i,1]==FALSE)
        {
                
                ifweekend[i,1] <- 1
        }else{
                
                ifweekend[i,1] <- 0
        }
}

forecastData$Weekday <- ifweekend

i <- 1
while(i<=nrow(forecastData))
{
        if(forecastData$Hour[i] >= 7 && forecastData$Hour[i] < 19)
        {
                forecastData$peakhour[i] <- 1
        }else if(forecastData$Hour[i] >= 19 || forecastData$Hour[i]<7)
        {
                forecastData$peakhour[i] <- 0
        }
        i<-i+1
}
names(forecastData)
str(forecastData)

forecastData$Wind_SpeedMPH <- as.numeric(forecastData$Wind_SpeedMPH)
library(zoo)
# replace all NAs with the previous value
na.locf(forecastData$Wind_SpeedMPH)

forecastinput <- forecastData[,c("Date","Month","Day","Year","Hour","Day_of_Week","Weekday","peakhour",
                                 "TemperatureF","Dew_PointF","Humidity","Sea_Level_PressureIn",
                                 "VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions",
                                 "WindDirDegrees")]

library(dplyr)
str(forecastinput)
forecastinputnew <- forecastinput


names(forecastinputnew)
str(forecastinputnew)

forecastinputnew = forecastinputnew %>% group_by(Date,Hour) %>% summarize(TemperatureF=mean(TemperatureF),
                                                                          Dew_PointF=mean(Dew_PointF),
                                                                          Humidity=mean(Humidity),
                                                                          Sea_Level_PressureIn = mean(Sea_Level_PressureIn),
                                                                          VisibilityMPH = mean(VisibilityMPH),
                                                                          Wind_SpeedMPH = mean(Wind_SpeedMPH),
                                                                          WindDirDegrees = mean(WindDirDegrees),
                                                                          Conditions = max(Conditions),
                                                                          Wind_Direction = max(Wind_Direction),
                                                                          Month= max(Month),Day=max(Day),Year=max(Year),
                                                                          Day_of_Week=max(Day_of_Week),Weekday=max(Weekday),
                                                                          peakhour=max(peakhour))

forecastinput <- forecastinputnew

nrow(forecastinput)
View(forecastinput)
write.csv(forecastinput, file = "ForecastInputNew.csv")
