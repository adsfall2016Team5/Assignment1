install.packages("Hmisc")
install.packages("psych")
install.packages("car")
library(Hmisc)
library(psych)
library(car)
library(caTools)
library(ISLR)
library(leaps)

df<-read.csv("SampleFormatfinal.csv")

# Replace missing values for categorical variables with mode of the variable
dfcon<-as.data.frame(df$Conditions)
dfconclean<-apply(dfcon, 2, function(x){ 
  x[is.na(x)] <- names(which.max(table(x)))
  return(x) })
df$Conditions<-as.factor(dfconclean)

dfwindir<-as.data.frame(df$WinddirDegrees)
dfwinclean<-apply(dfwindir, 2, function(x){ 
  x[is.na(x)] <- names(which.max(table(x)))
  return(x) })
df$WinddirDegrees<-as.factor(dfwinclean)
############################################################

# Structure the dataset
df<-df[,-1]
str(df)
temp<-as.Date(df$Date)
df$Date<-as.Date(df$Date)
df$Date<-as.Date(df$Date)
df$hour<-as.factor(df$hour)
df$Day.of.Week<-as.factor(df$Day.of.Week)
df$Weekday<-as.factor(df$Weekday)
############################################################

# Replace missing values for conitnous variables with mean of the variable
df$kWh<-as.numeric(impute(df$kWh,mean))
df$Temperature<-as.numeric(impute(df$Temperature,mean))
df$Dew_PointF<-as.numeric(impute(df$Dew_PointF,mean))
df$Humidity<-as.numeric(impute(df$Humidity,mean))
df$Sea_Level_PressureIn<-as.numeric(impute(df$Sea_Level_PressureIn,mean))
df$VisibilityMPH<-as.numeric(impute(df$VisibilityMPH,mean))
df$Wind_Direction<-as.numeric(impute(df$Wind_Direction,mean))
df$Wind_SpeedMPH<-as.numeric(impute(df$Wind_SpeedMPH,mean))


summary(df)

#############################################################

df1<-df[,c("Date","kWh","month","day","year","hour","Day.of.Week","Weekday","Peakhour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WinddirDegrees")]#,"kWh","month","hour","Day of Week","Weekday","Peakhour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WinddirDegrees")]

summary(df1)

# Spliting data into training and testing data
set.seed(101)
sample<- sample.split(df1$kWh,SplitRatio = 0.75)

df1<- subset(df1,sample==TRUE)
dfTest<- subset(df1,sample==FALSE)
#############################################################

# Creating linear regression model using backward selection
model1<-lm(kWh~.,data=df1)
summary(model1)
vif(model1)
plot(model1)

# Eliminate variables with high VIF values
model2<-update(model1,.~. -year)
summary(model2)
vif(model2)

model3<-update(model2,.~. -Weekday)
summary(model3)



model4<-update(model3,.~. -Peakhour)
summary(model4)
vif(model4)   

model5<-update(model4,.~. -Date)  
summary(model5)

vif(model5)

model6<-update(model5,.~. -Dew_PointF) 
summary(model6)
vif(model6)

model7<-update(model6,.~. -WinddirDegrees) 
summary(model7)
vif(model7)

# Eliminate variables with high P-values
model8<-update(model7,.~. -VisibilityMPH)
summary(model8)

model19<-update(model8,.~. -Wind_Direction) 
summary(model19)

model20<-update(model19,.~. -Conditions)
summary(model20)


model21<-update(model20,.~. -Wind_SpeedMPH) 
summary(model21)

model22<-update(model21,.~. -Humidity)
summary(model22)


crPlots(model22)

# Retrieving outliers using cook's distance
cutoff<- 4/((nrow(df1)-length(model22$coefficients)-2))
plot(model22,which = 4, cook.levels = cutoff)
plot(model22,which = 5, cook.levels = cutoff)
df1<-df1[-which(rownames(df1)%in%c("6941")),]

model23<-lm(kWh~month+day+hour+Day.of.Week+Temperature+Sea_Level_PressureIn,data = df1)
summary(model23)

cutoff<- 4/((nrow(df1)-length(model23$coefficients)-2))
plot(model23,which = 4, cook.levels = cutoff)
plot(model23,which = 5, cook.levels = cutoff)

df1<-df1[-which(rownames(df1)%in%c("5871","5866","5867")),]

model24<-lm(kWh~month+day+hour+Day.of.Week+Temperature+Sea_Level_PressureIn,data = df1)
summary(model24)

cutoff<- 4/((nrow(df1)-length(model24$coefficients)-2))
plot(model24,which = 4, cook.levels = cutoff)
plot(model24,which = 5, cook.levels = cutoff)

df1<-df1[-which(rownames(df1)%in%c("5865","5864","5868")),]

model25<-lm(kWh~month+day+hour+Day.of.Week+Temperature+Sea_Level_PressureIn,data = df1)
summary(model25)

cutoff<- 4/((nrow(df1)-length(model25$coefficients)-2))
plot(model25,which = 4, cook.levels = cutoff)
plot(model25,which = 5, cook.levels = cutoff)

df1<-df1[-which(rownames(df1)%in%c("5873")),]

model26<-lm(kWh~month+day+hour+Day.of.Week+Temperature+Sea_Level_PressureIn,data = df1)
summary(model26)

cutoff<- 4/((nrow(df1)-length(model26$coefficients)-2))
plot(model26,which = 4, cook.levels = cutoff)
plot(model26,which = 5, cook.levels = cutoff)
vif(model26)

# Correlation plot
df.sel<-subset(df1,select = c(month,day,hour,Day.of.Week,Temperature,Sea_Level_PressureIn))
pairs.panels(df.sel,col="red")



# Retrieving Regression coeffecients
Coeffecient<-as.data.frame(coef(model26))
colnames(Coeffecient)<-c("Coeffecient")
write.csv(Coeffecient,file = "RegressionOutputs.csv")


#Predicting  Test data
library(forecast)

prediction=predict(model26,dfTest)
performance<- as.data.frame(accuracy(prediction,df1$kWh))
write.csv(performance,file="PerformanceMetrics.csv")


# Part 3 Predicting power usage for ForcastInput csv
dfforecast<-read.csv("ForecastInputNew.csv")
str(dfforecast)
temp<-as.Date(dfforecast$Date)
dfforecast$Date<-as.Date(dfforecast$Date)
dfforecast$Date<-as.Date(dfforecast$Date)
dfforecast$hour<-as.factor(dfforecast$hour)
dfforecast$Day.of.Week<-as.factor(dfforecast$Day.of.Week)
dfforecast$Weekday<-as.factor(dfforecast$Weekday)
str(dfforecast)

prediction=predict(model27,dfforecast)
dfforecast$kWh<-prediction
str(dfforecast)
dfforecastoutput<-subset(dfforecast,select = c(month,day,hour,Day.of.Week,Temperature,Sea_Level_PressureIn,kWh))
write.csv(dfforecastoutput,file = "forecastOutput_Account_26908650026.csv")


#Regularization

install.packages("glmnet")
library(glmnet)

x <- model.matrix(kWh~month+day+hour+Day.of.Week+Temperature, df1)[,-1]
y <- df1$kWh
m <- cv.glmnet(x, y)
class(m)
n <- glmnet(m)
coef(m, m$lambda.min)
